# -*- coding: utf-8 -*-
"""Load the parameters of a shared parameter file into the active project,
bound to the Generic Models category.

- The user picks a shared parameter file (.txt), the groups to load,
  Instance or Type binding and the Properties group ("Group under").
- A parameter already in the project (same GUID) keeps its binding type and
  group; Generic Models is added to its categories if missing.
- A parameter whose NAME is already used in the project by a parameter with
  a different GUID (or a non-shared project parameter) is skipped - loading
  it would create a confusing duplicate.
- The Revit session's own shared parameter file setting is restored
  afterwards.

Notes for maintainers:
- Written to run on both pyRevit engines (CPython 3 and IronPython 2.7),
  matching this extension's convention (see B6U_BIM.tab/CODE_REVIEW.md).
  UI is plain System.Windows.Forms, not pyrevit.forms (stubbed under CPython).
- Uses the ForgeTypeId API (GroupTypeId, BindingMap.Insert/ReInsert with a
  ForgeTypeId): BuiltInParameterGroup no longer exists from Revit 2025 on.
"""
import os.path as op

import clr
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
from System.Windows.Forms import (
    Form, Label, CheckedListBox, Button, RadioButton, ComboBox, ComboBoxStyle,
    DialogResult, FormStartPosition, FormBorderStyle, MessageBox,
    MessageBoxButtons, MessageBoxIcon, OpenFileDialog,
)
from System.Drawing import Point, Size

from pyrevit import revit, DB, script

TITLE = "Load Shared Parameters"
TARGET_CATEGORY = DB.BuiltInCategory.OST_GenericModel
# (GroupTypeId attribute, fallback label) - first one is the default
GROUP_UNDER_CHOICES = [
    ("Data", "Data"),
    ("IdentityData", "Identity Data"),
    ("Text", "Text"),
    ("General", "General"),
    ("Ifc", "IFC Parameters"),
]
DEFAULT_SP_FILE = r"C:\ODP\OneDrive\_ODP_Claude\BERSnl OTL shared parameters\output\BERSnl_MowOtlSharedParameters.txt"


def alert(text, icon=MessageBoxIcon.Information):
    MessageBox.Show(text, TITLE, MessageBoxButtons.OK, icon)


def pick_shared_parameter_file(app):
    dlg = OpenFileDialog()
    dlg.Title = "Select a shared parameter file"
    dlg.Filter = "Shared parameter file (*.txt)|*.txt|All files (*.*)|*.*"
    start = DEFAULT_SP_FILE if op.isfile(DEFAULT_SP_FILE) else (app.SharedParametersFilename or "")
    if start and op.isdir(op.dirname(start)):
        dlg.InitialDirectory = op.dirname(start)
        dlg.FileName = op.basename(start)
    if dlg.ShowDialog() != DialogResult.OK:
        return None
    return dlg.FileName


def group_under_options():
    """[(label, ForgeTypeId)] for the Properties groups available in this Revit."""
    options = []
    for attr, fallback in GROUP_UNDER_CHOICES:
        gid = getattr(DB.GroupTypeId, attr, None)
        if gid is None:
            continue
        try:
            label = DB.LabelUtils.GetLabelForGroup(gid)
        except Exception:
            label = fallback
        options.append((label, gid))
    return options


def ask_options(sp_path, groups, category_name):
    """groups: [(group name, [ExternalDefinition])]. Returns dict or None."""
    group_opts = group_under_options()

    form = Form()
    form.Text = TITLE
    form.ClientSize = Size(440, 470)
    form.StartPosition = FormStartPosition.CenterScreen
    form.FormBorderStyle = FormBorderStyle.FixedDialog
    form.MinimizeBox = False
    form.MaximizeBox = False

    file_label = Label()
    file_label.Text = "File: " + op.basename(sp_path)
    file_label.Location = Point(12, 10)
    file_label.Size = Size(416, 18)
    form.Controls.Add(file_label)

    groups_label = Label()
    groups_label.Text = "Parameter groups to load:"
    groups_label.Location = Point(12, 34)
    groups_label.Size = Size(416, 18)
    form.Controls.Add(groups_label)

    checklist = CheckedListBox()
    checklist.Location = Point(12, 54)
    checklist.Size = Size(416, 220)
    checklist.CheckOnClick = True
    for name, defs in groups:
        checklist.Items.Add("{0}  ({1})".format(name, len(defs)), True)
    form.Controls.Add(checklist)

    cat_label = Label()
    cat_label.Text = "Category: " + category_name
    cat_label.Location = Point(12, 284)
    cat_label.Size = Size(416, 18)
    form.Controls.Add(cat_label)

    instance_rb = RadioButton()
    instance_rb.Text = "Instance"
    instance_rb.Location = Point(12, 310)
    instance_rb.Size = Size(90, 22)
    instance_rb.Checked = True
    form.Controls.Add(instance_rb)

    type_rb = RadioButton()
    type_rb.Text = "Type"
    type_rb.Location = Point(110, 310)
    type_rb.Size = Size(90, 22)
    form.Controls.Add(type_rb)

    under_label = Label()
    under_label.Text = "Group parameter under:"
    under_label.Location = Point(12, 344)
    under_label.Size = Size(150, 18)
    form.Controls.Add(under_label)

    under_combo = ComboBox()
    under_combo.DropDownStyle = ComboBoxStyle.DropDownList
    under_combo.Location = Point(165, 341)
    under_combo.Size = Size(263, 22)
    for label, _ in group_opts:
        under_combo.Items.Add(label)
    if group_opts:
        under_combo.SelectedIndex = 0
    form.Controls.Add(under_combo)

    note = Label()
    note.Text = ("Parameters already in the project (same GUID) keep their "
                 "Instance/Type and group; only the category is added.")
    note.Location = Point(12, 376)
    note.Size = Size(416, 34)
    form.Controls.Add(note)

    ok_btn = Button()
    ok_btn.Text = "Load"
    ok_btn.Size = Size(90, 26)
    ok_btn.Location = Point(240, 430)
    ok_btn.DialogResult = DialogResult.OK
    form.Controls.Add(ok_btn)

    cancel_btn = Button()
    cancel_btn.Text = "Cancel"
    cancel_btn.Size = Size(90, 26)
    cancel_btn.Location = Point(338, 430)
    cancel_btn.DialogResult = DialogResult.Cancel
    form.Controls.Add(cancel_btn)

    form.AcceptButton = ok_btn
    form.CancelButton = cancel_btn

    if form.ShowDialog() != DialogResult.OK:
        return None

    selected_defs = []
    for i, (_, defs) in enumerate(groups):
        if checklist.GetItemChecked(i):
            selected_defs.extend(defs)
    group_type_id = group_opts[under_combo.SelectedIndex][1] if group_opts else None
    return {
        "definitions": selected_defs,
        "instance": instance_rb.Checked,
        "group_type_id": group_type_id,
    }


def read_definitions(sp_file):
    groups = []
    for group in sp_file.Groups:
        defs = sorted(group.Definitions, key=lambda d: d.Name.lower())
        if defs:
            groups.append((group.Name, defs))
    return sorted(groups, key=lambda g: g[0].lower())


def existing_bindings(doc):
    """Return (by_guid, by_name) of the project's current parameter bindings.
    by_guid: guid string -> (definition, binding)
    by_name: name -> guid string, or None for a non-shared project parameter."""
    by_guid, by_name = {}, {}
    it = doc.ParameterBindings.ForwardIterator()
    it.Reset()
    while it.MoveNext():
        definition, binding = it.Key, it.Current
        guid = None
        elem = doc.GetElement(definition.Id)
        if isinstance(elem, DB.SharedParameterElement):
            guid = str(elem.GuidValue).lower()
            by_guid[guid] = (definition, binding)
        by_name[definition.Name] = guid
    return by_guid, by_name


def new_binding(app, category, instance):
    cats = app.Create.NewCategorySet()
    cats.Insert(category)
    if instance:
        return app.Create.NewInstanceBinding(cats)
    return app.Create.NewTypeBinding(cats)


def load_parameters(doc, app, category, options):
    result = {"added": [], "extended": [], "present": [], "conflict": [], "failed": []}
    by_guid, by_name = existing_bindings(doc)
    bindings = doc.ParameterBindings

    t = DB.Transaction(doc, TITLE)
    t.Start()
    try:
        for ext_def in options["definitions"]:
            name = ext_def.Name
            guid = str(ext_def.GUID).lower()
            try:
                if guid in by_guid:
                    definition, binding = by_guid[guid]
                    if binding.Categories.Contains(category):
                        result["present"].append(name)
                        continue
                    binding.Categories.Insert(category)
                    if bindings.ReInsert(definition, binding, definition.GetGroupTypeId()):
                        kind = "Instance" if isinstance(binding, DB.InstanceBinding) else "Type"
                        result["extended"].append("{0} (kept as {1})".format(name, kind))
                    else:
                        result["failed"].append("{0}: ReInsert refused".format(name))
                    continue

                if name in by_name:
                    other = by_name[name]
                    why = "project parameter (not shared)" if other is None else "GUID " + other
                    result["conflict"].append("{0}: name already used by {1}; file GUID {2}"
                                              .format(name, why, guid))
                    continue

                binding = new_binding(app, category, options["instance"])
                if bindings.Insert(ext_def, binding, options["group_type_id"]):
                    result["added"].append(name)
                    by_name[name] = guid
                else:
                    result["failed"].append("{0}: Insert refused".format(name))
            except Exception as ex:
                result["failed"].append("{0}: {1}".format(name, ex))
        t.Commit()
    except Exception:
        if t.HasStarted() and not t.HasEnded():
            t.RollBack()
        raise
    return result


def print_report(sp_path, category_name, options, result):
    output = script.get_output()
    output.print_md("### {0}".format(TITLE))
    print("File:     {0}".format(sp_path))
    print("Category: {0}  |  {1}".format(category_name,
                                          "Instance" if options["instance"] else "Type"))
    print("")
    sections = [
        ("Added", "added"),
        ("Existing - Generic Models added", "extended"),
        ("Already bound to Generic Models", "present"),
        ("Skipped - name conflict", "conflict"),
        ("Failed", "failed"),
    ]
    for title, key in sections:
        items = result[key]
        print("{0}: {1}".format(title, len(items)))
    for title, key in sections:
        items = result[key]
        if not items or key == "present":
            continue
        print("")
        print("{0}:".format(title))
        for item in items:
            print("  " + item)
    if result["conflict"] or result["failed"]:
        output.print_md("**Some parameters were not loaded - see the lists above.**")


def main():
    doc = revit.doc
    app = doc.Application
    if doc.IsFamilyDocument:
        alert("This tool works on a project, not on a family.", MessageBoxIcon.Warning)
        return

    category = DB.Category.GetCategory(doc, TARGET_CATEGORY)
    if category is None or not category.AllowsBoundParameters:
        alert("The Generic Models category is not available in this project.",
              MessageBoxIcon.Error)
        return

    sp_path = pick_shared_parameter_file(app)
    if not sp_path:
        return

    original_sp_path = app.SharedParametersFilename
    try:
        app.SharedParametersFilename = sp_path
        sp_file = app.OpenSharedParameterFile()
        if sp_file is None:
            alert("Revit could not read this shared parameter file:\n" + sp_path,
                  MessageBoxIcon.Error)
            return

        groups = read_definitions(sp_file)
        if not groups:
            alert("The file contains no parameters.", MessageBoxIcon.Warning)
            return

        options = ask_options(sp_path, groups, category.Name)
        if not options:
            return
        if not options["definitions"]:
            alert("No groups selected - nothing loaded.")
            return

        result = load_parameters(doc, app, category, options)
    finally:
        try:
            app.SharedParametersFilename = original_sp_path or ""
        except Exception:
            pass

    print_report(sp_path, category.Name, options, result)
    alert("Added: {0}\nGeneric Models added to existing: {1}\nAlready present: {2}\n"
          "Skipped (name conflict): {3}\nFailed: {4}\n\nDetails are in the output window."
          .format(len(result["added"]), len(result["extended"]), len(result["present"]),
                  len(result["conflict"]), len(result["failed"])),
          MessageBoxIcon.Warning if (result["conflict"] or result["failed"])
          else MessageBoxIcon.Information)


if __name__ == "__main__":
    main()
